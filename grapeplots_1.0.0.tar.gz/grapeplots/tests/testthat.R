library(testthat)
library(grapeplots)

test_check("grapeplots")
